create trigger WEATHER_TRIG
	before insert
	on WEATHERS
	for each row
DECLARE
  BEGIN
    if :new.weather_id is null then
      :new.weather_id := weather_sq.nextval;
    end if;
  END;